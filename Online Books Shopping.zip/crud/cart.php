<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<title></title>
	<link rel="icon" href="logo.png">
	<link rel="stylesheet" type="text/css" href="navbar.css">
</head>
<body>

</body>
</html>


<?php
include("connection.php");

session_start();
$pid = $_SESSION['cart'];
echo $pid;





?>