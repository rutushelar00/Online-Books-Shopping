-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Jan 19, 2024 at 12:53 AM
-- Server version: 10.4.32-MariaDB
-- PHP Version: 8.2.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `crud`
--

-- --------------------------------------------------------

--
-- Table structure for table `cart`
--

CREATE TABLE `cart` (
  `id` int(11) NOT NULL,
  `upload` varchar(500) NOT NULL,
  `book` varchar(50) NOT NULL,
  `category` varchar(50) NOT NULL,
  `author` varchar(50) NOT NULL,
  `prize` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `registration`
--

CREATE TABLE `registration` (
  `id` int(11) NOT NULL,
  `fname` varchar(20) NOT NULL,
  `mname` varchar(20) NOT NULL,
  `lname` varchar(20) NOT NULL,
  `mobile` varchar(12) NOT NULL,
  `email` varchar(50) NOT NULL,
  `gender` varchar(8) NOT NULL,
  `uname` varchar(20) NOT NULL,
  `pwd` varchar(20) NOT NULL,
  `cpwd` varchar(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `registration`
--

INSERT INTO `registration` (`id`, `fname`, `mname`, `lname`, `mobile`, `email`, `gender`, `uname`, `pwd`, `cpwd`) VALUES
(1, 'Rutuja', 'Anil', 'Shelar', '9087675867', 'rutu5055@gmail.com', 'Female', 'rutu00', '111', '111'),
(2, 'Mahek', 'Rifakat', 'Ansari', '9087657673', 'mahek1234@gmail.com', 'Female', 'mahek00', '222', '222'),
(3, 'Sakshi ', 'Kisan', 'Adsure', '9075775544', 'sakshi1234@gmail.com', 'Female', 'sakshi00', '333', '333'),
(4, 'Aditi', 'Jalindar', 'Chandre', '6765656787', 'aditi00@gmail.com', 'Female', 'aditi00', '444', '444'),
(5, 'Shivraj ', 'Vikas ', 'Gunjal', '9087564567', 'shivraj123@gmail.com', 'Male', 'shivraj111', '666', '666'),
(8, 'Janhvi', 'Ganesh', 'Kanade', '897645675', 'janhvi444@gmail.com', 'Female', 'janhvi123', '999', '999'),
(9, 'Krishna', 'Vishnu', 'Yadav', '7675656756', 'krishna123@gmail.com', 'Male', 'krish567', '901', '901'),
(10, 'Renuka', 'Aakash', 'Shirke', '8754675645', 'renuka3033@gmail.com', 'Female', 'renu2345', '1211', '1211'),
(11, 'Shivam', 'Ashok', 'Dahifale', '4545644445', 'shivam12@gmail.com', 'Male', 'shivam1234', 'shivam3035', 'shivam3035');

-- --------------------------------------------------------

--
-- Table structure for table `upload`
--

CREATE TABLE `upload` (
  `id` int(11) NOT NULL,
  `uploadfile` varchar(500) NOT NULL,
  `book` varchar(50) NOT NULL,
  `prize` varchar(50) NOT NULL,
  `category` varchar(30) NOT NULL,
  `author` varchar(50) NOT NULL,
  `descr` varchar(500) NOT NULL,
  `seller` varchar(60) NOT NULL,
  `address` varchar(100) NOT NULL,
  `contact` int(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `upload`
--

INSERT INTO `upload` (`id`, `uploadfile`, `book`, `prize`, `category`, `author`, `descr`, `seller`, `address`, `contact`) VALUES
(1, 'images/book1.png', 'Cosmos', 'Rs.400', 'Science', 'Carl Sagan', 'This is Science book lots of knowledge.', 'Govind Desai', 'Borivali, Mumbai Maharashtra 4044', 2147483647),
(2, 'images/book2.png', 'A Brief History of Time', 'Rs.900', 'Theoretical Cosmology', 'Stephen Hawking', 'Stephen Hawking explains a range of subjects in cosmology, including the Big Bang. ', 'Divya Bharti', 'Rahuri Ahmednagar', 2147483647),
(3, 'images/boo3.jpg', 'World History', 'Rs.250', 'History', 'Arjun Dev', 'the study of human history across boundaries. ', 'Abhijit Singh', 'Devlali pravara, Rahuri Ahmednagar', 799096765),
(4, 'images/book4.jpg', 'Physical Geography', 'Rs. 300', 'Geography', 'Savindra Singh', 'Geography Book by Savindra singh.', 'Aarohi Gupta', 'Kurla Pune, Maharashtra 085', 656565677),
(5, 'images/book5.jpg', 'Genome', 'Rs.500', 'Science', 'Matt Redley', 'The complete set of DNA (genetic material) in an organism.', 'Aarya Gupta', 'Jamkhed road Nimbodi Ahmednagar.', 2147483647),
(6, 'images/book6.jpg', 'NDA/NA 17 years', 'Rs.360', 'General Knowledge', 'Academy', 'NDA/ NA 17 year Topic-wise Solved Papers (2006 - 2022) consists of last 17 years  from 2006 - 2022.', 'Bookly Shop', 'Nimbalak Ahmednagar', 2147483647),
(7, 'images/book7.jpg', 'Biology NCERT ', 'Rs.300', 'Textbook', 'Textbook Publications', 'It includes a variety of topics like Reproduction in Organisms, Genetics and Evolution.', 'Neha Vare', 'Savedi Naka Savedi Ahmednagar.', 2147483647),
(8, 'images/book1.png', 'Cosmos', 'Rs.900', 'History', 'fhfhfg', 'This is Science book lots of knowledge.', 'tytyuyt', 'Rahuri Ahmednagar', 2147483647),
(9, 'images/phy.jpg', 'Concept of Physics', 'Rs.250', 'Science', 'H. C. Verma', 'HC Verma is one of the most popular books for physics among NEET aspirants.  ', 'Neha Joshi', 'Bolhegaon rd. behind parichay hotel, Ahmednagar', 2147483647),
(10, 'images/book8.jpg', 'The Logic of the lost Temple', 'Rs.100', 'Story Book', 'Sudha Murti', 'City girl Nooni is surprised at the pace of life in her grandparents’ village in Karnataka. ', 'Gayatri Desai', 'Pune', 2147483647),
(11, 'images/download', 'trtytytyt', 'rweew', 'terter', 'rtret', 'trtrtr', 'trtrt', 'tertert', 0),
(12, 'images/download.jpg', 'thfhgf', 'hfghgf', 'hghgf', 'hfghfgh', 'ghfghfghhhhjhmjhmhj', 'hnfghhhhhhhfghfg', 'hfghghfghfghh', 0),
(13, 'images/logoclg.jpg', 'rgret', 'retret', 'trtrt', 'trtr', 'trtr', 'trtterter', 'terterteterterter', 0);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `cart`
--
ALTER TABLE `cart`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `registration`
--
ALTER TABLE `registration`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `upload`
--
ALTER TABLE `upload`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `cart`
--
ALTER TABLE `cart`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `registration`
--
ALTER TABLE `registration`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=12;

--
-- AUTO_INCREMENT for table `upload`
--
ALTER TABLE `upload`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=14;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
