<?php
session_start();
$userprofile = $_SESSION['user_name'];

?>

<html>
<head>
    <title>Buy Books Online</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
    <link rel="icon" href="logo.png">
    <link rel="stylesheet" type="text/css" href="upload_display_style.css">
    <link rel="stylesheet" type="text/css" href="navbar.css">
    <style type="text/css">

        body{
            background-color: #B0A4A4;
        }

        th{
            background-color: lavender;
            color: #6F265C;
            font-size: 22px;
            margin-left: 20px;
        }

        td{
            font-weight: bold;
        }
            
    </style>
        }

</head>
    <body>
    <nav>
        <div class="navbar">
<a href="homepage.php"><i class="fa fa-fw fa-home"></i> Home</a> 
<a class="active" href="#"><i class="fa fa-shopping-basket" aria-hidden="true"></i>Buy Book</a> 
<a href="upload.php"><i class="fa fa-book" aria-hidden="true"></i>Sell Books</a> 
<a href="cart.php"><i class="fa fa-fw fa-cart-plus"></i>Cart</a>
<a href="profile.php"><i class="fa fa-fw fa-user"></i>Profile</a>  
</div><br></nav>
        

</body>
</html>



<?php 
include("connection.php");
error_reporting(0);

$userprofile = $_SESSION['user_name'];
if($userprofile == true)
{
    
}
else
{
    header('location:login.php');
}






$query = "SELECT * FROM UPLOAD ";
$data = mysqli_query($conn,$query);

$total = mysqli_num_rows($data);
//$result = mysqli_fetch_assoc($data);

echo $result["uploadfile"]."  ".$result["book"]."  ".$result["prize"]."  ".$result["category"]."  ".$result["author"]."  ".$result["descr"]."  ".$result["seller"];



//echo $total;

if($total != 0)
{
    ?>

    
    <form action="cart.php">
    <center><table  cellspacing="7" width="100%" class="tab">
        <tr style="position: fixed; background-color:#6F265C; margin-top: 0px; margin-left:0px; padding-left: 0px; margin-bottom: 100px;">
        <th width="2%">ID</th>
        <th width="5%">Image</th>
        <th width="10%">Name</th>
        <th width="10%">Prize</th>
        <th width="10%">Category</th>
        <th width="10%">Author</th>
        <th width="18%">Description</th>
        <th width="10%">Seller</th>
        <th width="10%">Contact</th>
        <th width="5%">Order</th>
        </tr>



        <form action="cart.php" method="POST" autocomplete="off">
            
    <?php
    while($result = mysqli_fetch_assoc($data))
    {
       
       echo" <tr>
        <td>". $result['id'] ."</td>
        <td><img src='".$result['uploadfile']."' height='150px' width='150px'></td>
        <td>". $result['book'] ."</td>
        <td>". $result['prize'] ."</td>
        <td>". $result['category'] ."</td>
        <td>". $result['author'] ."</td>
        <td>". $result['descr'] ."</td>
        <td>". $result['seller'] ."</td>
        <td>". $result['contact'] ?></td>
        <td><input type='submit' value='BuyNow' class='button'><a href="cart.php

            <?php 
            session_start();
            $_SESSION['cart'] = $pid;

            $pid        = $result['id']; echo $pid; 
            $uploadfile = $result['uploadfile']; echo $uploadfile;
            $book       = $result['book']; echo $book;
            $prize      = $result['prize']; echo $prize; 
            $category   = $result['category']; echo $category; 
            $author     = $result['author']; echo $author; 
            $descr      = $result['descr']; echo $descr; 
            $seller     = $result['seller']; echo $seller; 
            $contact    = $result['contact']; echo $contact;

;
            // $_SESSION['cart'] = $pid

            ?>">

        <input type="submit" value="AddToCart" class="button" name="add" style="background-color: #6495ED;"></a></td>

        </form>
        </tr>
         
<?php

    }
}
else
{
    echo 'No Records Found';
}

 ?>
</table>
</center>
</form>
