<?php
session_start();
$userprofile = $_SESSION['user_name'];
//echo $userprofile;

if($userprofile == true)
{
	
}
else
{
	header('location:login.php');
}



?>

<!DOCTYPE html>
<html>
<head>
	
	<title>Home page</title>
	<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
    
    <link rel="stylesheet" type="text/css" href="homepage_style.css">
    <link rel="stylesheet" type="text/css" href="navbar.css">
    <link rel="icon" href="logo.png">
    <style type="text/css">

    	.content{
    		display: flex;
    		justify-content: center;
    		align-items: center;
   }

   .slide_img{
   	height: 400px;
   	width: 700px;
   	margin-left: 40px;
	background-image: url("home_img.jpg");
	background-repeat: no-repeat;  
   	display: inline-block;

   }
    
    .slide_text{
    	height: 400px;
    	width: 600px;
    	text-align: center;
    	margin-left: 30px;
    	margin-top: 150px;
    	display: inline-block;
    	font-size: 30px;
    	text-shadow: 2px 2px 5px violet, 2px 2px 2px maroon;
    	animation-name: design;
    	animation-duration: 2s;
    	animation-timing-function: ease;
    	animation-iteration-count: infinite;
	}

	@keyframes design{
		0%{color: #990033;}
		20%{color: #666600;}
		40%{color: #520066;}
		60%{color: #00663d;}
		80%{color: #004d66;}
		100%{color: #003366;}
	}

    </style>
</head>
<body>
	<nav>
		<div class="navbar">
			
<a class="active" href="#" style="background-color:#957777; "><i class="fa fa-fw fa-home"></i> Home</a> 
<a href="upload_display.php"><i class="fa fa-shopping-basket" aria-hidden="true"></i>Buy Books</a> 
<a href="upload.php"><i class="fa fa-book" aria-hidden="true"></i>Sell Books</a> 
<a href="cart.php"><i class="fa fa-fw fa-cart-plus"></i>Cart</a>
<a href="profile.php" name="profile"><i class="fa fa-fw fa-user"></i>Profile</a>
      </div>
</nav><br><br>

<h1 style="text-shadow: 2px 2px 5px #6F265C, 2px 2px 2px purple;  font-size: 100px; text-align: center; color: lavender;">Online Books Shopping</h1>|<br><br>

<div class="content">

<div class="slide_text">
<h2>Increase your Knowledge<br> with Us...!!!</h2>	
</div>

<div class="slide_img">

</div>	

</div>
<br><br>

<footer>






</footer>




</body>
</html>





	