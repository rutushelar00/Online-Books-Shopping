<?php

include("connection.php");



$query = "SELECT * FROM UPLOAD WHERE id=1";

$data = mysqli_query($conn,$query);

$total = mysqli_num_rows($data);
$result = mysqli_fetch_assoc($data);

echo $total;


?>