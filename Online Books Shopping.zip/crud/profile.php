<?php
include("connection.php");
session_start();

$userprofile = $_SESSION['user_name'];
if($userprofile == true)
{
    
}
else
{
    header('location:login.php');
}

session_start();
$userprofile = $_SESSION['user_name'];
echo $userprofile;

$query = " SELECT * FROM REGISTRATION WHERE uname = '$userprofile' ";
$data = mysqli_query($conn,$query);

$total = mysqli_num_rows($data);
$result = mysqli_fetch_assoc($data);


//echo $total;






?>

<!DOCTYPE html>
<html>
<head>
    
    <title>Profile page</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
    <link rel="icon" href="logo.jpg">
    <link rel="icon" href="logo.png">
    <link rel="stylesheet" type="text/css" href="navbar.css">
    <style type="text/css">



.wraper{

    width:40%;
    background-color: black;
    margin: 20px auto;
    padding: 50px;
    box-shadow: 1px 1px 2px rgba(0,0,0,0.5);
    position: relative;
    top:110px;
    color: white;
    opacity:70%;
}

.wraper .title
{
    font-size: 24px;
    font-weight: 700;
    margin-bottom: 25px;
    color:#9F265C;
    text-align: center;
    opacity: 600%;

}
.wraper .text{
margin:20px 80px;

}

.sty{
    color: red;
 }

body{
    background-color: #B0A4A4;

    }
    </style>
</head>
<body>
    <nav>
        <div class="navbar">
            
<a href="homepage.php"><i class="fa fa-fw fa-home"></i> Home</a> 
<a href="upload_display.php"><i class="fa fa-shopping-basket" aria-hidden="true"></i>Buy Books</a> 
<a href="upload.php"><i class="fa fa-book" aria-hidden="true"></i>Sell Books</a> 
<a href="cart.php"><i class="fa fa-fw fa-cart-plus"></i>Cart</a>
<a class="active" href="#"><i class="fa fa-fw fa-user"></i>Profile</a>
      </div>
</nav><br><br>

<div class="wraper">
<center><img src="profile.jpg" height="100px" width="100px"></center>
<div class="title">MY PROFILE</div>

<div style="color:lavender;">
<h3>Account Hold by:</h3><div class="text">Name : <?php echo $result["fname"]."   ".$result["mname"]."   ".$result["lname"];

?>

<br><br>
Email: <?php echo $result["email"]; ?> <br><br>

Contact no: <?php echo $result["mobile"]; ?> <br><br>

User Name: <?php  echo $userprofile; ?><br><br>

</div>
</div>
<center>
    <div>
<h4 class="sty"><a href="login.php">Log in to existing Account</a></h4>
<h4><a href="form.php">Create new Account</a></h4>
</div>
<a href="logout.php"><input type="submit" name="" value="LogOut" style="font-size: 20px; font-weight: 10px; cursor: pointer; background-color:rgba(245, 39, 39, 0.50);border: none; color:lavender;"></a>
</center>


    </div>

</body>
</html>



