<?php
include("connection.php");

if(isset($_POST['add']))
{
  $id = $_POST['id'];

  $query = "SELECT * FROM UPLOAD WHERE id = '$_SESSION[cart]'";

  $data = mysqli_query($conn, $query);
  

  $total = mysqli_num_rows($data);
  //echo $total;

  

  if($total==1)
  {
    $_SESSION['cart'] = $id;
    


  }
  else
  {
    echo "Login Failed";
  }
}

?>