<?php
include("connection.php");
session_start();

$userprofile = $_SESSION['user_name'];
if($userprofile == true)
{
    
}
else
{
    header('location:login.php');
}

?>

<!DOCTYPE html>
<html lang="en">
<head>
    <title>Upload Books</title>
    <link rel="stylesheet" href="upload_style.css" type="text/css">
    <link rel="stylesheet" href="upload_display_style.css" type="text/css">
     <link rel="stylesheet" type="text/css" href="navbar.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
    <link rel="icon" href="logo.png">
    <style type="text/css">
        body{
    background-color: #B0A4A4;

    }
    </style>

</head>

<body>

        <nav>
        <div class="navbar">
<a href="homepage.php"><i class="fa fa-fw fa-home"></i> Home</a> 
<a href="upload_display.php"><i class="fa fa-shopping-basket" aria-hidden="true"></i>Buy Books</a> 
<a class="active" href="#"><i class="fa fa-book" aria-hidden="true"></i>Sell Books</a> 
<a href="cart.php"><i class="fa fa-fw fa-cart-plus"></i>Cart</a>
<a href="profile.php"><i class="fa fa-fw fa-user"></i>Profile</a>  
</div><br></nav>
        </nav>
    
        
<div class="container">
    <form action="#" method="POST" enctype="multipart/form-data">
                      <div class="title">UPLOAD BOOK</div>
    <div class="form">

        <h2>Book Details</h2><br>

         <label style="color: white; font-size: 15px;">Book Image:</label>
          <div class="inputfield">
          <input type="file" class="input" name="uploadfile" placeholder="Image" required>   
          </div>


          <div class="inputfield">
          <input type="text" class="input" name="book" placeholder="Book Name" required>   
          </div>
    
          <div class="inputfield">
          <input type="text" class="input" name="prize" placeholder="Prize"  required>   
          </div>
    
          <div class="inputfield">
          <input type="text" class="input" name="category" placeholder="Book Category" required>   
          </div>

          <div class="inputfield">
          <input type="text" class="input" name="author" placeholder="Author" required>   
          </div>

          <div class="inputfield">
          <input type="text" class="input" name="descr" placeholder="Description" required style="height: 60px;">   
          </div>
          

          <h2>Seller Details</h2><br>
    
          <div class="inputfield">
          <input type="text" class="input" name="seller" placeholder="Seller Name" required>   
          </div>
    
          <div class="inputfield">
          <input type="text" class="input" name="address" placeholder="Seller Address" required>   
          </div>

          <div class="inputfield">
          <input type="text" class="input" name="contact" placeholder="Contact Number" required>   
          </div>

          <div class="inputfield">
          <input type="submit" class="btn" name="upload" value="Upload">     
          </div>

  </div>

         </form>
</div>
</body>
</html>


<?php
if($_POST['upload'])
{


    $filename = $_FILES["uploadfile"]["name"];
    $tempname = $_FILES["uploadfile"]["tmp_name"];
    $folder = "images/".$filename;
    //echo $folder;
    move_uploaded_file($tempname, $folder);

    //print_r($_FILES['uploadfile']);

    
    $book = $_POST['book'];
    $prize = $_POST['prize'];
    $category = $_POST['category'];
    $author = $_POST['author'];
    $descr = $_POST['descr'];
    $seller = $_POST['seller'];
    $address = $_POST['address'];
    $contact = $_POST['contact'];

    $query = "INSERT INTO UPLOAD (uploadfile,book,prize,category,author,descr,seller,address,contact)
     VALUES('$folder','$book','$prize','$category','$author','$descr','$seller','$address','$contact')";

    $data = mysqli_query($conn,$query);

    if($data)
    {
        echo "Book Uploaded Successfully into Database";
    }
    else
    {
        echo "Book Upload Failed".mysqli_connect_error();
    }
}
?>