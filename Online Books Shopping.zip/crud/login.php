<?php
session_start();

?>

<!DOCTYPE html>
<html lang="en">
<head>
    <title>Login</title>
    <link rel="stylesheet" href="login_style.css" type="text/css">
</head>

<body>
        
<div class="center">
       <h1>LOGIN</h1>
       <form action="#" method="POST" autocomplete="off">
        <div class="form">
                  <input type="text" name="uname" class="textfilled" placeholder="UserName" required>
                  <input type="password" name="pwd" class="textfilled" placeholder="Password" required>

                 <div class="forgetpass"><a href="#" class="link">Forget Password ?</a></div>

                <input type="submit" name="login" value="Login" class="btn">

              <div class="signup">Don't you have Register ?  <a href="form.php" class="link"> Register Here </a></div>
    </div>
  </form>
</div>
</body>
</html>

<?php
include("connection.php");

if(isset($_POST['login']))
{
  $username = $_POST['uname'];
  $password = $_POST['pwd'];

  $query = "SELECT * FROM registration WHERE uname = '$username' && pwd = '$password' ";

  $data = mysqli_query($conn, $query);
  

  $total = mysqli_num_rows($data);
  //echo $total;

  

  if($total==1)
  {
    $_SESSION['user_name'] = $username;
    header('location:homepage.php');


  }
  else
  {
    echo "Login Failed";
  }
}

?>



    