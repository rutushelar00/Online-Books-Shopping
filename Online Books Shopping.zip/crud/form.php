<?php
include("connection.php");
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <title>Sign Up Form</title>
    <link rel="stylesheet" href="style.css" type="text/css">
</head>
<body>
        
<div class="container">
    <form action="#" method="POST">
                      <div class="title">REGISTRATION FORM</div>
    <div class="form">

          <div class="inputfield">
          <label>First Name</label>
          <input type="text" class="input" name="fname" required>   
          </div>

          <div class="inputfield">
          <label>Middle Name</label>
          <input type="text" class="input" name="mname" required>   
          </div>
    
          <div class="inputfield">
          <label>Last Name</label>
          <input type="text" class="input" name="lname" required>   
          </div>
    
          <div class="inputfield">
          <label>Mobile No.</label>
          <input type="tel" class="input" name="mobile" required>   
          </div>

          <div class="inputfield">
          <label>Email Address</label>
          <input type="text" class="input" name="email" required>   
          </div>
    
          <div class="inputfield">
          <label>Gender</label>
          <select class="selectbox" name=gender required>
          <option value="Not Selected">Select</option>
          <option value="Male">Male</option>
          <option value="Female">Female</option>
          </select>  
          </div>
    
          <div class="inputfield">
          <label>User Name</label>
          <input type="text" class="input" name="uname" required>   
          </div>
    
          <div class="inputfield">
          <label>Password</label>
          <input type="text" class="input" name="pwd" required>   
          </div>

          <div class="inputfield">
          <label>Confirm Password</label>
          <input type="text" class="input" name="cpwd" required>   
          </div>

          <div class="inputfield">
          <input type="submit" class="btn" name="register" value="Register">     
          </div>

          <div class="signup">Allready you have Register ?<a href="login.php" class="link">Login Here</a></div>

  </div>

         </form>
</div>
</body>
</html>


<?php
if($_POST['register'])
{
    $first = $_POST['fname'];
    $middle = $_POST['mname'];
    $last = $_POST['lname'];
    $number = $_POST['mobile'];
    $mail = $_POST['email'];
    $gender = $_POST['gender'];
    $user = $_POST['uname'];
    $password = $_POST['pwd'];
    $confirm = $_POST['cpwd'];

    $query = "INSERT INTO REGISTRATION (fname,mname,lname,mobile,email,gender,uname,pwd,cpwd) VALUES('$first','$middle','$last','$number','$mail','$gender','$user','$password','$confirm')";

    $data = mysqli_query($conn,$query);

    if($data)
    {
        echo "Data Succesfully Inserted Into Database";
    }
    else
    {
        echo "Failed".mysqli_connect_error();
    }
}
?>
